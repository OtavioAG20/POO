import fatec.poo.model.Aluno;
import fatec.poo.model.Professor;
/**
 *
 * @author 0030482421016
 */
public class Aplic {
    public static void main(String[] args) {
        Aluno objAlu = new Aluno(1010, "Carlos Silveira", "15/03/1978");
        Professor objProf = new Professor(2020,"So isso", "31/02/1910");
        objAlu.setMensalidade(1500);
        objProf.setSalario(0.99);
        System.out.println("O registro escolar do aluno: " + objAlu.getRegEscolar());
        System.out.println("O nome do aluno: " + objAlu.getNome());
        System.out.println("A data de nascimento do aluno: " + objAlu.getDataNascimento());
        System.out.println("A mensalidade do aluno: " + objAlu.getMensalidade());
        
        System.out.println("\nRegistro do funcionario: " + objProf.getRegFuncional());
        System.out.println("Nome do professor: " + objProf.getNome());
        System.out.println("Data de nascimento: " + objProf.getDataNascimento());
        System.out.println("Salario do professor: " + objProf.getSalario());
        
    }
    
}
