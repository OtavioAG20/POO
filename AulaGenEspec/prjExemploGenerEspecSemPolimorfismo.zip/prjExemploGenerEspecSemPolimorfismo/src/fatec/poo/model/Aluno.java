package fatec.poo.model;
/**
 *
 * @author 0030482421016
 */
public class Aluno extends Pessoa{
        private int regEscolar; 
        private double mensalidade;
        
        public Aluno(int re, String n, String dt){
            super(n,dt);// chamada do método construtor da classe Pessoa. Super SEMPRE vai represntar a superclasse
            regEscolar = re;
        }
        
        public int getRegEscolar(){
            return regEscolar;
        }
        
        public double getMensalidade(){
            return mensalidade;
        }
        
        public void setMensalidade(double x){
           mensalidade = x;
        }
        
        
}
