package fatec.poo.model;
/**
 *
 * @author 0030482421016
 */
public class Pessoa {
    private String nome;
    private String dataNascimento;
    
    public Pessoa(String n, String dt){
        nome = n;
        dataNascimento = dt;
    }
    public String getNome(){
        return nome; 
    }
    public String getDataNascimento(){
        return dataNascimento;
    }
}
