package fatec.poo.model;

/**
 *
 * @author 0030482421016
 */
public class Professor extends Pessoa{
    private int regFuncionario;
    private double salario;
    
    public Professor(int rf, String n, String dt){
        super(n, dt);
        regFuncionario = rf;
    }
    
    public void setSalario(double s){
        salario = s;
    }
    
    public int getRegFuncional(){
        return regFuncionario;
    }
    
    public double getSalario(){
        return salario;
    }
}
