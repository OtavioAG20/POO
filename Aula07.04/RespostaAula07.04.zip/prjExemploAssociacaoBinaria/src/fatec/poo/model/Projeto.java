package fatec.poo.model;

/**
 *
 * @author Otavio
 */
public class Projeto {
    private int codigo, numFunc;
    private String descricao;
    private String dtInicio, dtTermino;
    private Funcionario funcionarios[];
    
    public Projeto(int c, String d){
        codigo = c;
        descricao = d;
        funcionarios = new Funcionario[5];
    }

    public int getCodigo() {
        return codigo;
    }
    public String getDescricao() {
        return descricao;
    }

    public String getDtInicio() {
        return dtInicio;
    }

    public String getDtTermino() {
        return dtTermino;
    }

    public Funcionario[] getFuncionarios() {
        return funcionarios;
    }

    public void setDtInicio(String dtInicio) {
        this.dtInicio = dtInicio;
    }

    public void setDtTermino(String dtTermino) {
        this.dtTermino = dtTermino;
    }
    
    public void addFuncionarios(Funcionario f){
        funcionarios[numFunc] = f;
        numFunc++;
    }
    public void listarFuncionarios(){
        System.out.println("Codigo: " + getCodigo() + "\nDescricao: " + getDescricao() + "\nData Inicio" + getDtInicio() + "\nData termino: " + getDtTermino() + "\nQuantidade de funcionarios: " + numFunc);
        System.out.println("Registro\t\tNome\t\t\tCargo\t\t\tDepartamento");
        for(int x=0; x < numFunc; x++){
            System.out.println(funcionarios[x].getRegistro() + "\t\t"
                               + funcionarios[x].getNome() + "\t\t\t" + funcionarios[x].getCargo() + "\t\t\t" 
                                + funcionarios[x].getProjeto().getDescricao());
        }
    }
    
    
    
}
