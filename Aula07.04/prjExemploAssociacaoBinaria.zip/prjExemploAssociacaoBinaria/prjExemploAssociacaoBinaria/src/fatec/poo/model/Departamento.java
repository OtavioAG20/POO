package fatec.poo.model;

/**
 *
 * @author 0030482421016
 */
public class Departamento {
    private String sigla, nome;
    private Funcionario funcionarios[];//definição de uma matriz de objetos que representa uma matriz de ponteiro indicando a multiplicidade 1..*
    private int numFunc ;//Indice da matriz de objetos;
    
    public Departamento(String sigla, String nome) {
        this.sigla = sigla;
        this.nome = nome;
        funcionarios = new Funcionario[5];
        numFunc = 0;//indica a posição do primeiro elemento da matriz
    }

    public String getSigla() {
        return sigla;
    }

    public String getNome() {
        return nome;
    }
    
    public void addFuncionario(Funcionario f){//tem como parâmetro de entrada o endereço de uma objeto da classe FuncionarioHorista, FuncionarioMensalista, FuncionarioComisisonado
        funcionarios[numFunc] = f;
        numFunc ++;
    }
    
    public void listaFuncionarios(){
        System.out.println("Sigla: " + getSigla() + " Nome: " + getNome() + " Quantidade de funcionários: " + numFunc);
        System.out.println("\nRegistro\t\tNome\tCargo");
        for(int x=0; x < numFunc; x++){
            System.out.println(funcionarios[x].getRegistro() + "\t\t");
            System.out.println(funcionarios[x].getNome() + "\t\t");
            System.out.println(funcionarios[x].getCargo() + "\n");
        }
    }
    
        
    
}
