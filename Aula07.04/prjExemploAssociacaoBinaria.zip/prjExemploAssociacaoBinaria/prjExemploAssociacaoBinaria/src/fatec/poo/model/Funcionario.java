package fatec.poo.model;

/**
 *
 * @author 0030482421016
 */
public abstract class Funcionario {
        private int registro;
        private String nome;
        private String dtAdmissao;
        private String cargo;
        private Departamento departamento = null;//atributo ponteiro, que armazena o endereço de um objeto da
                                                 //classe departamento, está representando a multiplicidade 1.
        
        public Funcionario(int r, String n, String da){
            registro = r;
            nome = n;
            dtAdmissao = da;
        }
        
        //Método abstrato, apresenta apenas a assinatura
        abstract public double calcSalBruto();
        
        public double calcDesconto(){
            return 0.10 * calcSalBruto();
        }
        
        public double calcSalLiquido(){
         return calcSalBruto() - calcDesconto();   
        }
        
        public int getRegistro(){
            return registro;
        }
        
        public String getNome(){
            return nome;
        }
        
        public String getDtAdmissao(){
            return dtAdmissao;
        }
       
        public void setCargo(String c){
            cargo = c;
        }
        public String getCargo(){
            return cargo;
        }

        public Departamento getDepartamento() {
        return departamento;
        }

        //Tem como parâmetro de entrada o endereço de um objeto da classe Departamento
        public void setDepartamento(Departamento departamento) {
        this.departamento = departamento;
        }
        
}
