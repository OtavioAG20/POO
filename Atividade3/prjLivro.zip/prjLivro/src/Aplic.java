import java.util.Scanner;
/**
 *
 * @author Otavio
 */
public class Aplic {
    
    public static void main(String[] args) {
        double valMulta;
        int identidade, atraso, opc;
        
        Scanner entrada = new Scanner(System.in);
        
        System.out.println("Digite o nome do livro:");
        String title = entrada.nextLine();
        System.out.println("Digite o numero do livro:");
        identidade = entrada.nextInt();
        System.out.println("Digite o valor para a multa:");
        valMulta = entrada.nextDouble();
        
        Livro objLiv = new Livro(identidade, title);
        objLiv.setValorMultaDiara(valMulta);
        
                do{
            System.out.println("\n1-Consultar Livro\n2-Emprestar Livro\n3-Devolver Livro\n4-Sair");
            System.out.println("\t\tDigite a opção que você deseja: ");
            opc = entrada.nextInt();
            if(opc ==1){
                System.out.println("O titulo do livro: " + objLiv.getTitulo() + "\nNúmero do Livro: " + objLiv.getIdentificacao());
                if(objLiv.getSituacao()==false)
                    System.out.println("Situação: Disponível");
                else
                    System.out.println("Situacão: Indisponível");
            }
            else{
                if(opc==2){
                    objLiv.emprestar();
                }
                else{
                    if(opc==3){
                        if(objLiv.getSituacao()==false){
                            System.out.println("O livro já está disponível");
                        }
                        else{
                            System.out.println("Digite a quantidade de dias atrasado: ");
                            atraso = entrada.nextInt();
                            System.out.println("Operação de devolução realizada com sucesso!\nO valor da multa a se pagar: " + objLiv.devolver(atraso));
                        }
                    }
                }
            }
            
        }while(opc!=4);
        
    
    }
}
