/**
 *
 * @author Otavio
 */
public class Livro {
        private int identificacao;
        private double valMultaDiaria;
        private boolean situacao;
        private String titulo;
        
        public Livro(int x, String book){
            identificacao = x;
            titulo = book;
        }
        public void setValorMultaDiara(double x){
            valMultaDiaria = x;
        }
        public int getIdentificacao(){
            return identificacao;
        }
        public String getTitulo(){
            return titulo;
        }
        public boolean getSituacao(){
            return situacao;
        }
        public void emprestar(){
            if(situacao ==true){
                System.out.println("O lirvo está emprestado!");
            }
            else{
                situacao = true;
                System.out.println("Operação de empréstimo realizado com sucesso!");
            }
            
        }
        public double devolver(int diasAtrasado){
            situacao = false;
            return (diasAtrasado * valMultaDiaria);
        }
        
        
}

