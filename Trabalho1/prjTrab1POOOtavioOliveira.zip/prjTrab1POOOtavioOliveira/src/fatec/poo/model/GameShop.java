package fatec.poo.model;

/**
 *
 * @author Otavio
 */
public class GameShop {
    private int codigo, idade, saldo;
    private String nome;
    private boolean tipoGamer;

    public GameShop(int codigo,String nome, boolean tipoGamer, int saldo) {
        this.codigo = codigo;
        this.saldo = saldo;
        this.nome = nome;
        this.tipoGamer = tipoGamer;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public int getCodigo() {
        return codigo;
    }

    public int getSaldo() {
        return saldo;
    }

    public String getNome() {
        return nome;
    }

    public boolean isTipoGamer() {
        return tipoGamer;
    }
    public void jogarHoras(int horas){
            saldo = saldo - horas;
    }
    public void comprarHoras(int compra){
        saldo +=compra;
        
        if(tipoGamer == true){
            saldo += compra/3;
        }
    }
    public void brinde(){
        saldo = saldo * 2;
    }
    
}
