import fatec.poo.model.FuncionarioHorista;
import fatec.poo.model.FuncionarioMensalista;
/**
 *
 * @author 0030482421016
 */
public class Aplic {
    public static void main(String[] args) {
        FuncionarioHorista funcHor = new FuncionarioHorista(1010, "Pedro Silveira", "10/02/2020", 15.80);
        FuncionarioMensalista funcMens = new FuncionarioMensalista(1111, "Otavio Augusto", "04/02/2004", 12.00);
        
        funcMens.setCargo("Programador");
        funcHor.setCargo("Gerente");
        
        
        funcHor.setQtdeHorTrab(90);
        System.out.println("Nome: " + funcHor.getNome());
        System.out.println("Registro: " + funcHor.getRegistro());
        System.out.println("Data de admissão: " + funcHor.getDtAdmissao());
        System.out.println("Cargo: " + funcHor.getCargo());
        System.out.println("Salario Bruto: " + funcHor.calcSalBruto());
        System.out.println("Gratificação: " + funcHor.calcGratificacao());
        System.out.println("Desconto: " + funcHor.calcDesconto());
        System.out.println("Salario Liquido: " + funcHor.calcSalLiquido());
        
        funcMens.setNumSalMinimo(30);
        System.out.println("\nNome: " + funcMens.getNome());
        System.out.println("Registro: " + funcMens.getRegistro());
        System.out.println("Data de admissão: " + funcMens.getDtAdmissao());
        System.out.println("Cargo: " + funcMens.getCargo());
        System.out.println("Valor Salário Minimo: " + funcMens.calcSalBruto());
        System.out.println("Desconto: " + funcMens.calcDesconto());
        System.out.println("Salario Liquido: " + funcMens.calcSalLiquido());
    }
    
}
