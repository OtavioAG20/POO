package fatec.poo.model;
import java.util.ArrayList;

/**
 *
 * @author Fatec
 */
public abstract class Pessoa {
    private String nome;
    private int anoInscricao;
    private double totalCompras; 
    private ArrayList<PedidoCompra> pedidosCompras;
    public Pessoa(String n, int anoIns){
        nome = n;
        anoInscricao = anoIns; 
        pedidosCompras = new ArrayList<PedidoCompra>();
    }
    
    abstract public double calcBonus(int anoAtual);
    
    public void addCompras(double val){
        totalCompras += val;
    //totalCompras = totalCompras + val
    }
    
    public String getNome() {
        return nome;
    }

    public int getAnoInscricao() {
        return anoInscricao;
    }

    public double getTotalCompras() {
        return totalCompras;
    }
    public int getQtdePedidos(){
        return pedidosCompras.size();
    }
    
    
    public void cadPedidos(PedidoCompra p){
        pedidosCompras.add(p);
        p.setPessoa(this);
        this.addCompras(p.getValor());
    }
    
    
    
}

