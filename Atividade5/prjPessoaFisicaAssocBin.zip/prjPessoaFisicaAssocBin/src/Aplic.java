import fatec.poo.model.PessoaFisica;
import fatec.poo.model.PessoaJuridica;
import fatec.poo.model.PedidoCompra;
import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author Dimas
 */

public class Aplic {
    public static void main(String[] args) {       
        Scanner entrada = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("#,##0.00");      
        
        int nPed, opcao, anoInsc, anoAtual, cont = 0;
        String cpf_cgc, nome, dtPed;
        double valComp, valBase, txIncentivo;
        
        System.out.println("Digite o cpf da pessoa fisica: ");
        cpf_cgc = entrada.nextLine();
        System.out.println("Digite o nome da pessoa:");
        nome = entrada.nextLine();
        System.out.println("Digite o ano de inscricao: ");
        anoInsc = entrada.nextInt();
        System.out.println("Digite o valor base: ");
        valBase = entrada.nextDouble();
        
        
        PessoaFisica objPf = new PessoaFisica(cpf_cgc, nome, anoInsc);
        objPf.setBase(valBase);
        entrada.nextLine();
        
        
        System.out.println("Digite o cgc da pessoa juridica: ");
        cpf_cgc = entrada.nextLine();
        System.out.println("Digite o nome da pessoa: ");
        nome = entrada.nextLine();
        System.out.println("Digite o ano de inscricao: ");
        anoInsc = entrada.nextInt();
        System.out.println("Digite a taxa de incentivo:");
        txIncentivo = entrada.nextDouble();
        
        System.out.println("Digite o ano atual: ");
        anoAtual = entrada.nextInt();
        
        PessoaJuridica objPj = new PessoaJuridica(cpf_cgc, nome, anoInsc);
        objPj.setTaxaIncentivo(txIncentivo);
        
        do{
            System.out.println("REGISTRE ATE 10 PEDIDOS DE COMPRAS!\n1-Registrar compra de pessoa fisica!\n2-Registrar compra juridica\n3-Sair");
            opcao = entrada.nextInt();
            if(opcao ==1){
                System.out.println("Digite o numero do pedido:");
                nPed = entrada.nextInt();
                entrada.nextLine();
                System.out.println("Digite a data do pedido:");
                dtPed = entrada.nextLine();
                System.out.println("Digite o valor do pedido:");
                valComp = entrada.nextDouble();
                
                PedidoCompra pedido = new PedidoCompra(nPed);
                pedido.setDataPedido(dtPed);
                pedido.setValor(valComp);
                objPf.cadPedidos(pedido);                
            }
            else if(opcao ==2){
                System.out.println("Digite o numero do pedido:");
                nPed = entrada.nextInt();
                entrada.nextLine();
                System.out.println("Digite a data do pedido:");
                dtPed = entrada.nextLine();
                System.out.println("Digite o valor do pedido:");
                valComp = entrada.nextDouble();
                
                PedidoCompra pedido = new PedidoCompra(nPed);
                pedido.setDataPedido(dtPed);
                pedido.setValor(valComp);
                objPj.cadPedidos(pedido);                
            }
            cont ++;
        }while(cont < 10 && opcao !=3);
        
        System.out.println("CPF: " + objPf.getCPF() + "\nNome: " + objPf.getNome() + "Total das Compras: " + df.format(objPf.getTotalCompras())
                + "\nNúmero de pedidos: " + objPf.getQtdePedidos() + "Bônus: " + df.format(objPf.calcBonus(anoAtual)));
        System.out.println("CPF: " + objPj.getCGC() + "\nNome: " + objPj.getNome() + "Total das Compras: " + df.format(objPj.getTotalCompras())
                + "\nNúmero de pedidos: " + objPj.getQtdePedidos() + "Bônus: " + df.format(objPj.calcBonus(anoAtual)));
    }
}
