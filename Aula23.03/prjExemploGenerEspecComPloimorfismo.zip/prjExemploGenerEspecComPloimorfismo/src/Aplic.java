import fatec.poo.model.FuncionarioHorista;
import fatec.poo.model.FuncionarioMensalista;
/**
 *
 * @author 0030482421016
 */
public class Aplic {
    public static void main(String[] args) {
        FuncionarioHorista funcHor = new FuncionarioHorista(1010, "Pedro Silveira", "10/02/2020", 15.80);
        FuncionarioMensalista funcMens = new FuncionarioMensalista(1111, "Otavio Augusto", "04/02/2004", 12.00);
        
        funcHor.setQtdeHorTRab(90);
        System.out.println("Salario Bruto: " + funcHor.calcSalBruto());
        System.out.println("Desconto: " + funcHor.calcDesconto());
        System.out.println("Salario Liquido: " + funcHor.calcSalLiquido());
        
        funcMens.setNumSalMinimo(30);
        System.out.println("Valor Salário Minimo: " + funcMens.calcSalBruto());
        System.out.println("Desconto: " + funcMens.calcDesconto());
        System.out.println("Salario Liquido: " + funcMens.calcSalLiquido());
    }
    
}
