package fatec.poo.model;

/**
 *
 * @author 0030482421016
 */
public abstract class Funcionario {
        private int registro;
        private String nome;
        private String dtAdmissao;
        
        public Funcionario(int r, String n, String da){
            registro = r;
            nome = n;
            dtAdmissao = da;
        }
        
        //Método abstrato, apresenta apenas a assinatura
        abstract public double calcSalBruto();
        
        public double calcDesconto(){
            return 0.10 * calcSalBruto();
        }
        
        public double calcSalLiquido(){
            return calcSalBruto() - calcDesconto();
        }
        
}
