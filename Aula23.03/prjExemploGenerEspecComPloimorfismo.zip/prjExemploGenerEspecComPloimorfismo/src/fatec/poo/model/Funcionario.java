package fatec.poo.model;

/**
 *
 * @author 0030482421016
 */
public abstract class Funcionario {
        private int registro;
        private String nome;
        private String dtAdmissao;
        private String cargo;
        
        public Funcionario(int r, String n, String da, String c){
            registro = r;
            nome = n;
            dtAdmissao = da;
            cargo = c;
        }
        
        //Método abstrato, apresenta apenas a assinatura
        abstract public double calcSalBruto();
        
        public double calcDesconto(){
            return 0.10 * calcSalBruto();
        }
        
        abstract public double calcSalLiquido();
        
        public int getRegistro(){
            return registro;
        }
        
        public String getNome(){
            return nome;
        }
        
        public String getDtAdmissao(){
            return dtAdmissao;
        }
       
        public String getCargo(){
            return cargo;
        }
        
}
