package fatec.poo.model;

/**
 *
 * @author 0030482421016
 */
public class FuncionarioHorista extends Funcionario{
    private double valHorTrab;
    private int qtdeHorTrab;
    
    
    public FuncionarioHorista(int r, String n, String da, double vht, String c){
        super(r, n, da, c);
        valHorTrab = vht;
    }
    
    public void setQtdeHorTrab(int qht){
        qtdeHorTrab = qht;
    }
    
    //aplicação do polimorfismo
    public double calcSalBruto(){
        return valHorTrab * qtdeHorTrab;
    }
    
    public double calcGratificacao(){
        return 0.075 * calcSalBruto();
    }
    
    public double calcSalLiquido(){
        return (calcSalBruto() + calcGratificacao()) - calcDesconto();
    }
}
