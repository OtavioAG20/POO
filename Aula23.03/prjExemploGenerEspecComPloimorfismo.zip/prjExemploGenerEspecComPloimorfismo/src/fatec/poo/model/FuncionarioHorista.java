package fatec.poo.model;

/**
 *
 * @author 0030482421016
 */
public class FuncionarioHorista extends Funcionario{
    private double valHorTrab;
    private int qtdeHorTrab;
    
    
    public FuncionarioHorista(int r, String n, String da, double vht){
        super(r, n, da);
        valHorTrab = vht;
    }
    
    public void setQtdeHorTRab(int qht){
        valHorTrab = qht;
    }
    
    //aplicação do polimorfismo
    public double calcSalBruto(){
        return valHorTrab * qtdeHorTrab;
    }
}
