import fatec.poo.model.Departamento;
import fatec.poo.model.FuncionarioHorista;
import fatec.poo.model.FuncionarioMensalista;
import fatec.poo.model.FuncionarioComissionado;

/**
 *
 * @author 0030482421016
 */
public class Aplic {

    public static void main(String[] args) {
        FuncionarioHorista funcHor = new FuncionarioHorista(1010, "Pedro Silveira", "10/02/2020", 15.80);
        FuncionarioMensalista funcMens = new FuncionarioMensalista(1111, "Otavio Augusto", "04/02/2004", 12.00);
        FuncionarioComissionado funcComi= new FuncionarioComissionado(2020, "Melissa", "28/01/1993", 0.10);
        funcMens.setCargo("Programador");
        funcHor.setCargo("Gerente");
        funcComi.setCargo("Vendedora");
        funcComi.setSalBase(2000);
        funcComi.addVendas(10001);
        funcHor.setQtdeHorTrab(90);
        Departamento dep1 = new Departamento("CP", "Compras");
        
        //Estabelecendo a ligação(apontamento) entre um objeto da classe funcionariohorista com um objeto da classe Departamento
        funcHor.setDepartamento(dep1);
        funcMens.setDepartamento(dep1);
        System.out.println("O funcionário Hosrista " + funcHor.getNome() + "trabalha no departamento de: " + funcHor.getDepartamento().getNome());
        System.out.println("O funcionário Mensalista " + funcMens.getNome() + "trabalho no departamento de" + funcMens.getDepartamento().getNome());
    }
    
}
