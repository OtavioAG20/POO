import java.util.Scanner;
/**
 *
 * @author Otavio
 */
public class Aplic {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        Circulo objCirc = new Circulo();
        double medRaio;
        int opc;
        
        System.out.println("Digite o raio do círculo: ");
        medRaio = entrada.nextDouble();
        
        objCirc.setRaio(medRaio);
        
       do{
         System.out.println("\n1-Consulte a medida da área");
         System.out.println("2-Consulte a medida do perímetro");
         System.out.println("3-Consulte a medida do diâmetro");
         System.out.println("4-SAIR");
         System.out.println("Digite a opção: ");
         opc = entrada.nextInt();
         
         if(opc ==1){
             System.out.println("A medida da área: " + objCirc.calcArea());
         }
         else{
             if(opc==2){
                 System.out.println("A medida do perímetro: " + objCirc.calcPeri());
             }
             else{
                 if(opc==3){
                     System.out.println("A medida do diâmetro: " + objCirc.calcDiam());
                 }
                 else{
                     if(opc < 1 || opc > 4){
                         System.out.println("ERRO!");
                     }
                     
                 }
             }
         }
       }while(opc < 4);
    }
    
}
