import java.util.Scanner;
/**
 *
 * @author Otavio
 */
public class Aplic {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        Aluno objAlu = new Aluno();
        
        int RA, opc;
        double NtPrv1, NtPrv2, NtTrab1, NtTrab2;
        
        System.out.println("\nDigite o RA do aluno: ");
        RA = entrada.nextInt();
        System.out.println("Digite a nota da primeira prova: ");
        NtPrv1 = entrada.nextDouble();
        System.out.println("Digite a nota da segunda prova: ");
        NtPrv2 = entrada.nextDouble();
        System.out.println("Digite a nota do primeiro trabalho: ");
        NtTrab1 = entrada.nextDouble();
        System.out.println("Digite a nota do segundo trabalho: ");
        NtTrab2 = entrada.nextDouble();
        
        objAlu.setRA(RA);
        objAlu.setNtPrv1(NtPrv1);
        objAlu.setNtPrv2(NtPrv2);
        objAlu.setTrab1(NtTrab1);
        objAlu.setTrab2(NtTrab2);
        
        do{
        System.out.println("\nRA do aluno: " + objAlu.getRA());
        System.out.println("1-Consultar media das provas\n2-Cosnultar media dos trabalhos\n3-Consultar a media final\n4-SAIR\nDIGITE A OPCAO: ");
        opc = entrada.nextInt();
        if(opc ==1){
            System.out.println("A media das provas foi: " + objAlu.calcMedPrv());
        }
        else{
            if(opc ==2){
                System.out.println("A media dos trabalhos foi: " + objAlu.calcMedTrb());
            }
            else{
                if(opc==3){
                    System.out.println("A media final do aluno foi: " + objAlu.calcMedidaFinal());
                }
                else{
                    if(opc < 1 || opc > 4){
                        System.out.println("ERRO");
                    }
                }
            }
        }
        }while(opc < 4);
    }
    
}
