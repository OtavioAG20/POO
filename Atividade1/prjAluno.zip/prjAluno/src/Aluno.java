
/**
 *
 * @author Otavio
 */
public class Aluno {
    private double NtPrv1, NtPrv2, NtTrab1, NtTrab2;
    private int RA;
    double medPrv, medTrab;
    
    public void setRA(int x){
        RA = x;
    }
    public void setNtPrv1(double p1){
        NtPrv1 = p1;
    }
    public void setNtPrv2(double p2){
        NtPrv2 = p2;
    }
    public void setTrab1(double trb1){
        NtTrab1 = trb1;
    }
    public void setTrab2(double trb2){
        NtTrab2 = trb2;
    }
    public int getRA(){
        return RA;
    }
    public double getPrv1(){
        return NtPrv1;
    }
    public double getPrv2(){
        return NtPrv2;
    }
    public double getTrab1(){
        return NtTrab1;
    }
    public double getTrab2(){
        return NtTrab2;
    }
    public double calcMedPrv(){
        medPrv = (0.75 * (NtPrv1 + (2 * NtPrv2)))/3;
        return medPrv;
    }
    public double calcMedTrb(){
        medTrab = 0.25 * ((NtTrab1 + NtTrab2)/2); 
        return medTrab;
    }
    public double calcMedidaFinal(){
        return medTrab + medPrv;
    }
}