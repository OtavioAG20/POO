/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fatec.poo.model;

/**
 *
 * @author 0030482421016
 */
public class Hotel {
      private int codigo;
      private String nome, endereco, telefone;
      private double valorDiaria, totalFaturamento;
      
     public Hotel(int codigo, String nome){
         this.codigo = codigo;
         this.nome = nome;
     }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getValorDiaria(){
        return String.valueOf(valorDiaria);
    }

    public void setValorDiaria(double valorDiaria) {
        this.valorDiaria = valorDiaria;
    }
    public String getTotalFaturamento(){
        return String.valueOf(totalFaturamento);
    }
    public void addValorHospedagen(double valDiaria){
        totalFaturamento += valDiaria;
    }
    
    
}
